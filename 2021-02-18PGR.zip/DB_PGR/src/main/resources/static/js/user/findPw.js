var findPwButton = document.querySelector('#findPw')
var formElem = document.querySelector('#form')
var userEmailElem = formElem.userEmail.value
var usernicknameElem = formElem.nickname.value

var param = {
	userEmail: userEmailElem.value,
	usernickname: usernicknameElem.value
}
if (findPwButton) {
	function ajax() {

		fetch('/findPw', {
			method: 'get',
			headers: {
				'Content-type': 'application/json',
			},
			body: JSON.stringify(param)
		}).then(function(res) {
			return res.json()
		}).then(function(myJson) {
			if (myJson) {
				alert('발송완료')
				proc(myJson)
			}
		})

		function proc(myJson) {
			var checkMsg = document.querySelector('#checkMsg')
			if (myJson) {
				function ajax2() {
					fetch('/findPwSend', {
						method: 'post',
						headers: {
							'Content-type': 'application/json',
						},
						body: JSON.stringify(param)
					})
				}
				checkMsg.innerHTML('<p style="color:darkblue"></p>')
				href.location = "/login"
			} else {
				checkMsg.innerHTML('<p style="color:red">일치하는 정보가 없습니다.</p>')
			}
		}




	}

}


findPwButton.addEventListener('click', ajax)

