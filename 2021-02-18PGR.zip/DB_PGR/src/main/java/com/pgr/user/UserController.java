package com.pgr.user;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pgr.rm.model.MailDTO;
import com.pgr.rm.model.UserEntity;

@Controller
public class UserController {
	
	@Autowired
	private JavaMailSender javaMailSender;
	
	@Autowired 
	private EmailServiceImpl emailservice;

	@Autowired
	private UserService service;

	@GetMapping("/join")
	public void join() {
	} // 회원가입 화면 맵핑

	@ResponseBody
	@PostMapping("/join") // 회원가입 정보 DB 전달
	public Map<String, Object> join(@RequestBody UserEntity p) {
		System.out.println("dd");
		Map<String, Object> map = new HashMap<>();
		map.put("result", service.join(p));

		return map;
	}

	@GetMapping("/login")
	public void login() {

	}

	@ResponseBody
	@PostMapping("/login")
	public Map<String, Object> login(@RequestBody UserEntity p, HttpSession hs) {

		Map<String, Object> map = new HashMap<>();
		map.put("result", service.login(p, hs));

		return map;
	}

	@GetMapping("/logout")
	public String logout(HttpSession hs) {
		hs.invalidate();
		return "redirect:/user/login";
	}

	@PostMapping("/CheckMail") // AJAX와 URL을 매핑
	public Map<String, Object> SendMail(UserEntity p) {
		Map<String, Object> map = new HashMap<>();
		Random random = new Random();
		String key = "";

		System.out.println("usermail : " + p.getUserEmail());
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(p.getUserEmail()); // 스크립트에서 보낸 메일을 받을 사용자 이메일 주소
		// 입력 키를 위한 코드
		for (int i = 0; i < 3; i++) {
			int index = random.nextInt(25) + 65; // A~Z까지 랜덤 알파벳 생성
			key += (char) index;
		}
		int numIndex = random.nextInt(8999) + 1000; // 4자리 정수를 생성
		key += numIndex;
		message.setSubject("인증번호 입력을 위한 메일 전송");
		message.setText("인증 번호 : " + key);
		javaMailSender.send(message);
		map.put("key", key);
		return map;
	}

	// Email과 name의 일치여부를 check하는 컨트롤러
	@GetMapping("/findPw")
	@ResponseBody
	public Map<String, Boolean> pw_find(String userEmail, String userName) {
		Map<String, Boolean> map = new HashMap<>();
		boolean pwFindCheck = service.userEmailCheck(userEmail, userName);

		System.out.println(pwFindCheck);
		map.put("check", pwFindCheck);
		return map;
	}

	// 등록된 이메일로 임시비밀번호를 발송하고 발송된 임시비밀번호로 사용자의 pw를 변경하는 컨트롤러
	@PostMapping("/findPwSend")
	@ResponseBody
	public void sendEmail(@RequestBody String userEmail, String userName) {
		MailDTO dto = emailservice.createMailAndChangePassword(userEmail, userName);
		emailservice.mailSend(dto);

	}
}
