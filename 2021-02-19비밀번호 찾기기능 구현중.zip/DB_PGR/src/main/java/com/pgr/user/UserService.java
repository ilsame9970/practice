package com.pgr.user;

import java.io.PrintWriter;

import javax.mail.Message.RecipientType;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.pgr.rm.model.UserEntity;

@Service
public class UserService {

	@Autowired
	private UserMapper mapper;

	@Autowired
	private SecurityUtils sUtils;

	@Autowired
	private JavaMailSender emailSender;

	public int join(UserEntity p) {
		UserEntity check = mapper.selUser(p);
		System.out.println("email : " + p.getUserEmail());
		System.out.println("Pw : " + p.getUserPw());
		System.out.println("nickname : " + p.getNickname());

		if (p.getUserEmail().equals("")) { // 아이디(이메일)칸이 비어 있으면 0을 리턴
			return 0;
		}

		// 비밀번호를 암호화
		String salt = sUtils.getSalt();
		String hashPw = sUtils.getHashPw(p.getUserPw(), salt);

		if (check != null) { // 이미 있는 아이디(이메일)이면 1을 리턴
			return 1;
		}
		if (p.getUserPw().equals("")) { // 비밀번호 칸이 비어 있으면 2을 리턴
			return 2;
		}
		if (p.getUserPwRe().equals("")) { // 비밀번호 확인 칸이 비어 있으면 3을 리턴
			return 3;
		}
		if (p.getNickname().equals("")) { // 닉네임 칸이 비어 있으면 4를 리턴
			return 4;
		}
		if (!p.getUserPw().equals(p.getUserPwRe())) { // 비밀번호와 비밀번호 확인 칸의 값이 다르면 5를 리턴
			return 5;
		}
		p.setUserPw(hashPw);

		mapper.insUser(p); // if문에서 하나도 안걸리면 정보를 입력

		return 6; // 회원가입이 성공하면 6를 리턴
	}

	// 1: 로그인 성공, 2: 아이디 없음, 3: 비밀번호가 틀림, 0: 에러
	public int login(UserEntity p, HttpSession hs) {
		UserEntity check = mapper.selUser(p);

		if (check == null) {
			System.out.println("아이디 없음");
			return 2;
		}

		if (!BCrypt.checkpw(p.getUserPw(), check.getUserPw())) {
			return 3;
		}

		check.setUserPw(null);
		check.setRegDt(null);
		hs.setAttribute(Const.KEY_LOGINUSER, check);
		System.out.println("성공");
		return 1;
	}

	public MimeMessage sendEmail(UserEntity p, String div) throws Exception {

		MimeMessage message = emailSender.createMimeMessage();

		message.addRecipients(RecipientType.TO, p.getNickname());// 보내는 대상
		message.setSubject("PGR 임시 비밀번호가 도착했습니다.");// 제목

		String msgg = "";

		if (div.equals("findPw")) {
			msgg = "PGR 임시 비밀번호 입니다.";
			msgg += "<div align='center' style='border:1px solid black; font-family:verdana'>";
			msgg += "<h3 style='color: blue;'>";
			msgg += p.getNickname() + "님의 임시 비밀번호 입니다. 비밀번호를 변경하여 사용하세요.</h3>";
			msgg += "<p>임시 비밀번호 : ";
			msgg += p.getUserPw() + "</p></div>";
		}

		message.setText(msgg, "utf-8", "html");// 내용
		message.setFrom(new InternetAddress(Const.FROM_ADDRESS));
		return message;

	}

	public int findPw(UserEntity p) throws Exception {
		UserEntity check = mapper.selUser(p);
		System.out.println("nickname : " + p.getNickname());
		System.out.println("email : " + p.getUserEmail());
		// 이메일이 없으면
		if (check == null) {
			return 1;
		}
		// 가입된 닉네임이 아니면
		if (!p.getNickname().equals(check.getNickname())) {
			return 2;
		} else {
			// 임시 비밀번호 생성
			String pw = "";
			for (int i = 0; i < 12; i++) {
				pw += (char) ((Math.random() * 26) + 97);
			}
			p.setUserPw(pw);
			// 비밀번호 변경
			mapper.updateUserPassword(p);
			// 비밀번호 변경 메일 발송
			sendEmail(p, "findPw");

			return 3;
		}

	}
	
	public UserEntity selUser(UserEntity p) {
		return mapper.selUser(p);
	}

}
