package com.pgr.user;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.pgr.rm.model.MailDTO;
import com.pgr.rm.model.UserEntity;

@Controller
public class UserController {

	@Autowired
	private UserService service;

	@GetMapping("/join")
	public void join() {
	} // 회원가입 화면 맵핑

	@ResponseBody
	@PostMapping("/join") // 회원가입 정보 DB 전달
	public Map<String, Object> join(@RequestBody UserEntity p) {
		System.out.println("p : " + p);
		System.out.println("nickname : " + p.getNickname());
		Map<String, Object> map = new HashMap<>();
		map.put("result", service.join(p));

		return map;
	}

	@GetMapping("/login")
	public void login() {

	}

	@ResponseBody
	@PostMapping("/login")
	public Map<String, Object> login(@RequestBody UserEntity p, HttpSession hs) {

		Map<String, Object> map = new HashMap<>();
		map.put("result", service.login(p, hs));

		return map;
	}

	@GetMapping("/logout")
	public String logout(HttpSession hs) {
		hs.invalidate();
		return "redirect:/user/login";
	}

	@GetMapping("/findPw")
	public void pw_find(UserEntity p) {
	}

	@ResponseBody
	@PostMapping("/findPw")
	public Map<String, Object> findPw(@RequestBody UserEntity p) throws Exception {
		System.out.println("nickname : " + p.getNickname());
		System.out.println("email : " + p.getUserEmail());
		Map<String, Object> map = new HashMap<>();
		map.put("result", service.findPw(p));
		return map;
	}

}
