package com.pgr.user;

import java.util.Random;

import javax.mail.Message.RecipientType;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.pgr.rm.model.MailDTO;
import com.pgr.rm.model.UserEntity;

@Service
public class EmailServiceImpl {

	@Autowired
	private JavaMailSender emailSender;

	@Autowired
	private SecurityUtils sUtils;
	
	@Autowired
	private UserMapper mapper;
	
	public static final String ePw = createKey();
	private static final String FROM_ADDRESS = "ilsame9970@gmail.com";

	private MimeMessage createMessage(String to) throws Exception {
		System.out.println("보내는 대상 : " + to);
		System.out.println("인증 번호 : " + ePw);
		MimeMessage message = emailSender.createMimeMessage();

		message.addRecipients(RecipientType.TO, to);// 보내는 대상
		message.setSubject("PGR 인증번호가 도착했습니다.");// 제목

		String msgg = "";
		msgg += "<div style='margin:100px;'>";
		msgg += "<h1> 안녕하세요  PGR입니다!!! </h1>";
		msgg += "<br>";
		msgg += "<p>아래 코드를 회원가입 창으로 돌아가 입력해주세요<p>";
		msgg += "<br>";
		msgg += "<p>감사합니다!<p>";
		msgg += "<br>";
		msgg += "<div align='center' style='border:1px solid black; font-family:verdana';>";
		msgg += "<h3 style='color:blue;'>회원가입 코드입니다.</h3>";
		msgg += "<div style='font-size:130%'>";
		msgg += "CODE : <strong>";
		msgg += ePw + "</strong><div><br/> ";
		msgg += "</div>";
		message.setText(msgg, "utf-8", "html");// 내용
//		message.setFrom(new InternetAddress("properties에 작성한 이메일", "PGR"));// 보내는 사람
		message.setFrom(new InternetAddress(FROM_ADDRESS));
		return message;
	}

//		인증코드 만들기
	public static String createKey() {
		StringBuffer key = new StringBuffer();
		Random rnd = new Random();

		for (int i = 0; i < 8; i++) { // 인증코드 8자리
			int index = rnd.nextInt(3); // 0~2 까지 랜덤

			switch (index) {
			case 0:
				key.append((char) ((int) (rnd.nextInt(26)) + 97));
				// a~z (ex. 1+97=98 => (char)98 = 'b')
				break;
			case 1:
//				key.append((char) ((int) (rnd.nextInt(26)) + 65));
				// A~Z
				break;
			case 2:
				key.append((rnd.nextInt(10)));
				// 0~9
				break;
			}
		}

		return key.toString();
	}

	public void sendSimpleMessage(String to) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("to : " + to);
		MimeMessage message = createMessage(to);
		try {// 예외처리
			emailSender.send(message);
		} catch (MailException es) {
			es.printStackTrace();
			throw new IllegalArgumentException();
		}

	}

	public MailDTO createMailAndChangePassword(String userEmail, String userNickname) {
		String str = getTempPassword();
		MailDTO dto = new MailDTO();
		dto.setAddress(userEmail);
		dto.setTitle(userNickname + "님의 PGR 임시비밀번호 안내 이메일 입니다.");
		dto.setMessage("안녕하세요. PGR 임시비밀번호 안내 관련 이메일 입니다." + "[" + userNickname + "]" + "님의 임시 비밀번호는 " + str + " 입니다.");
		updatePassword(str, userEmail);
		return dto;
	}

	public void updatePassword(String str, String userEmail) {
		String salt = sUtils.getSalt();
		String cryptPw = sUtils.getHashPw(str, salt);

		String pw = cryptPw;
		mapper.updateUserPassword(pw);
	}

	public String getTempPassword() {
		char[] charSet = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F',
				'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };

		String str = "";

		int idx = 0;
		for (int i = 0; i < 10; i++) {
			idx = (int) (charSet.length * Math.random());
			str += charSet[idx];
		}
		return str;
	}
	
	  public void mailSend(MailDTO mailDto){
	        System.out.println("이멜 전송 완료!");
	        SimpleMailMessage message = new SimpleMailMessage();
	        message.setTo(mailDto.getAddress());
	        message.setFrom(FROM_ADDRESS);
	        message.setSubject(mailDto.getTitle());
	        message.setText(mailDto.getMessage());

	        emailSender.send(message);
	    }

}
