package com.pgr.user;

public class Const {
	public static final String KEY_LOGINUSER = "loginUser";
	public static final String KEY_LIST = "list";
	public static final String KEY_DATA = "data";
	public static final String KEY_MENULIST = "menuList";
}
