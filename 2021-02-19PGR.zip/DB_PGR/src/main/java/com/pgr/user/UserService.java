package com.pgr.user;

import javax.servlet.http.HttpSession;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pgr.rm.model.UserEntity;

@Service
public class UserService {

	@Autowired
	private UserMapper mapper;

	@Autowired
	private SecurityUtils sUtils;

	public int join(UserEntity p) {
		UserEntity check = mapper.selUser(p);

		if (p.getUserEmail().equals("")) { // 아이디(이메일)칸이 비어 있으면 0을 리턴
			return 0;
		}

		// 비밀번호를 암호화
		String salt = sUtils.getSalt();
		String hashPw = sUtils.getHashPw(p.getUserPw(), salt);

		if (check != null) { // 이미 있는 아이디(이메일)이면 1을 리턴
			return 1;
		}
		if (p.getUserPw().equals("")) { // 비밀번호 칸이 비어 있으면 2을 리턴
			return 2;
		}
		if (p.getUserPwRe().equals("")) { // 비밀번호 확인 칸이 비어 있으면 3을 리턴
			return 3;
		}
		if (p.getNickname().equals("")) { // 닉네임 칸이 비어 있으면 4를 리턴
			return 4;
		}
		if (!p.getUserPw().equals(p.getUserPwRe())) { // 비밀번호와 비밀번호 확인 칸의 값이 다르면 5를 리턴
			return 5;
		}
		p.setUserPw(hashPw);

		mapper.insUser(p); // if문에서 하나도 안걸리면 정보를 입력

		return 6; // 회원가입이 성공하면 6를 리턴
	}

	// 1: 로그인 성공, 2: 아이디 없음, 3: 비밀번호가 틀림, 0: 에러
	public int login(UserEntity p, HttpSession hs) {
		UserEntity check = mapper.selUser(p);

		if (check == null) {
			System.out.println("아이디 없음");
			return 2;
		}

		if (!BCrypt.checkpw(p.getUserPw(), check.getUserPw())) {
			return 3;
		}

		check.setUserPw(null);
		check.setRegDt(null);
		hs.setAttribute(Const.KEY_LOGINUSER, check);
		System.out.println("성공");
		return 1;
	}

	public boolean userEmailCheck(String userEmail, String userNickname) {
		UserEntity user = mapper.findUserByUserId(userEmail);
		if (user != null && user.getNickname().equals(userNickname)) {
			return true;
		} else {
			return false;
		}
	}

}
