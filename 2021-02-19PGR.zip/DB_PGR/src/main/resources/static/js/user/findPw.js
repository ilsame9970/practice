var findPwButton = document.querySelector('#findPw')
var formElem = document.querySelector('#form')
var userEmailElem = formElem.userEmail.value
var usernicknameElem = formElem.nickname.value

var param = {
	userEmail: userEmailElem.value,
	usernickname: usernicknameElem.value
}

if (findPwButton) {
	function ajax() {
		fetch ('/findPw', {
			method: 'post',
			headers: {
				'Content-type': 'application/json',
			},
			body: JSON.stringify(param)
		})
			
		

	}

}


findPwButton.addEventListener('click', ajax)

